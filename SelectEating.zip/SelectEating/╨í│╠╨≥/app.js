//app.js
App({
  //定义全局变量：是否刷新页面。为false不执行刷新
  isReloadOrderList: false,
})